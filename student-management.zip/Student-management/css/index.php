<?php
    header("location: ../404.php");
?>