<?php

$con = mysqli_connect("localhost", "root", "", "student_management");
// if($con){
//     echo "successfull";
// }else{
//     echo "Not successfull";
// }

?>